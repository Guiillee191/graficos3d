Para mover la camara lateralmente y hacia arriba y abajo utilizar wasd.
Para cambiar la zona de enfoque de la camara solo hace falta mover el raton, no hace falta hacer click,
el programa fijará el raton en el centro de la pantalla y desactivará su visivilidad.
